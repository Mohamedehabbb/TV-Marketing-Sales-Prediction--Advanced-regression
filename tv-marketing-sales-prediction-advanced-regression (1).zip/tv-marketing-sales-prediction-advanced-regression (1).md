```python
# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python Docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the read-only "../input/" directory
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# You can write up to 20GB to the current directory (/kaggle/working/) that gets preserved as output when you create a version using "Save & Run All" 
# You can also write temporary files to /kaggle/temp/, but they won't be saved outside of the current session
```

# project overview
**This project analyzes TV Marketing (Advertising) data to understand how advertising spend across different channels impacts product Sales.

The project is treated as a real-world business problem, focusing not only on prediction accuracy but also on interpretability, insights, and decision-making support.**

# import libraries



```python
import pandas as pd
import numpy as np

import matplotlib.pyplot as plt
import seaborn as sns
```

# load datasets # 




```python
import pandas as pd

df = pd.read_csv('/kaggle/input/advertising-dataset/advertising.csv')
df.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>TV</th>
      <th>Radio</th>
      <th>Newspaper</th>
      <th>Sales</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>230.1</td>
      <td>37.8</td>
      <td>69.2</td>
      <td>22.1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>44.5</td>
      <td>39.3</td>
      <td>45.1</td>
      <td>10.4</td>
    </tr>
    <tr>
      <th>2</th>
      <td>17.2</td>
      <td>45.9</td>
      <td>69.3</td>
      <td>12.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>151.5</td>
      <td>41.3</td>
      <td>58.5</td>
      <td>16.5</td>
    </tr>
    <tr>
      <th>4</th>
      <td>180.8</td>
      <td>10.8</td>
      <td>58.4</td>
      <td>17.9</td>
    </tr>
  </tbody>
</table>
</div>



# EDA & visualization


```python
df.describe().T
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>count</th>
      <th>mean</th>
      <th>std</th>
      <th>min</th>
      <th>25%</th>
      <th>50%</th>
      <th>75%</th>
      <th>max</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>TV</th>
      <td>200.0</td>
      <td>147.0425</td>
      <td>85.854236</td>
      <td>0.7</td>
      <td>74.375</td>
      <td>149.75</td>
      <td>218.825</td>
      <td>296.4</td>
    </tr>
    <tr>
      <th>Radio</th>
      <td>200.0</td>
      <td>23.2640</td>
      <td>14.846809</td>
      <td>0.0</td>
      <td>9.975</td>
      <td>22.90</td>
      <td>36.525</td>
      <td>49.6</td>
    </tr>
    <tr>
      <th>Newspaper</th>
      <td>200.0</td>
      <td>30.5540</td>
      <td>21.778621</td>
      <td>0.3</td>
      <td>12.750</td>
      <td>25.75</td>
      <td>45.100</td>
      <td>114.0</td>
    </tr>
    <tr>
      <th>Sales</th>
      <td>200.0</td>
      <td>15.1305</td>
      <td>5.283892</td>
      <td>1.6</td>
      <td>11.000</td>
      <td>16.00</td>
      <td>19.050</td>
      <td>27.0</td>
    </tr>
  </tbody>
</table>
</div>






```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 200 entries, 0 to 199
    Data columns (total 4 columns):
     #   Column     Non-Null Count  Dtype  
    ---  ------     --------------  -----  
     0   TV         200 non-null    float64
     1   Radio      200 non-null    float64
     2   Newspaper  200 non-null    float64
     3   Sales      200 non-null    float64
    dtypes: float64(4)
    memory usage: 6.4 KB
    

**no missing values & datatype is float**


```python
df.isna().sum().plot(kind='bar')
```




    <Axes: >




    
![png](output_12_1.png)
    



```python
df.isnull().sum()
```




    TV           0
    Radio        0
    Newspaper    0
    Sales        0
    dtype: int64



**there isnot any missing & null values**


```python
sns.pairplot(df)
plt.show()

```

    /usr/local/lib/python3.11/dist-packages/seaborn/_oldcore.py:1119: FutureWarning: use_inf_as_na option is deprecated and will be removed in a future version. Convert inf values to NaN before operating instead.
      with pd.option_context('mode.use_inf_as_na', True):
    /usr/local/lib/python3.11/dist-packages/seaborn/_oldcore.py:1119: FutureWarning: use_inf_as_na option is deprecated and will be removed in a future version. Convert inf values to NaN before operating instead.
      with pd.option_context('mode.use_inf_as_na', True):
    /usr/local/lib/python3.11/dist-packages/seaborn/_oldcore.py:1119: FutureWarning: use_inf_as_na option is deprecated and will be removed in a future version. Convert inf values to NaN before operating instead.
      with pd.option_context('mode.use_inf_as_na', True):
    /usr/local/lib/python3.11/dist-packages/seaborn/_oldcore.py:1119: FutureWarning: use_inf_as_na option is deprecated and will be removed in a future version. Convert inf values to NaN before operating instead.
      with pd.option_context('mode.use_inf_as_na', True):
    /usr/local/lib/python3.11/dist-packages/seaborn/axisgrid.py:118: UserWarning: The figure layout has changed to tight
      self._figure.tight_layout(*args, **kwargs)
    


    
![png](output_15_1.png)
    



```python
sns.heatmap(df.corr(),annot =True)
```




    <Axes: >




    
![png](output_16_1.png)
    


**we find that a tv has astrong relation with sales**


```python
fig, axs = plt.subplots(4, figsize = (7,11))
plt1 = sns.boxplot(df['TV'], ax = axs[0])
plt2 = sns.boxplot(df['Newspaper'], ax = axs[1])
plt3 = sns.boxplot(df['Radio'], ax = axs[2])
plt3 = sns.boxplot(df['Sales'], ax = axs[3])


plt.tight_layout()
```


    
![png](output_18_0.png)
    


# Features and Target


```python
X = df[['TV', 'Radio', 'Newspaper']]
y = df['Sales']
```


```python
print(X.shape)
print(y.shape)
```

    (200, 3)
    (200,)
    

# split data 


```python
from sklearn.model_selection import train_test_split 
X_train , X_test , y_train , y_test = train_test_split(X,y,test_size=0.2,random_state=42)
```


```python
X_train.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>TV</th>
      <th>Radio</th>
      <th>Newspaper</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>79</th>
      <td>116.0</td>
      <td>7.7</td>
      <td>23.1</td>
    </tr>
    <tr>
      <th>197</th>
      <td>177.0</td>
      <td>9.3</td>
      <td>6.4</td>
    </tr>
    <tr>
      <th>38</th>
      <td>43.1</td>
      <td>26.7</td>
      <td>35.1</td>
    </tr>
    <tr>
      <th>24</th>
      <td>62.3</td>
      <td>12.6</td>
      <td>18.3</td>
    </tr>
    <tr>
      <th>122</th>
      <td>224.0</td>
      <td>2.4</td>
      <td>15.6</td>
    </tr>
  </tbody>
</table>
</div>




```python
y_train.head()
```




    79     11.0
    197    14.8
    38     10.1
    24      9.7
    122    16.6
    Name: Sales, dtype: float64




```python
print(X_train.shape)
print(X_test.shape)
print(y_train.shape)
print(y_test.shape)
```

    (160, 3)
    (40, 3)
    (160,)
    (40,)
    

# try linear regression model 


```python
from sklearn.linear_model import LinearRegression
lr = LinearRegression()
lr.fit(X_train,y_train)

```




<style>#sk-container-id-1 {color: black;background-color: white;}#sk-container-id-1 pre{padding: 0;}#sk-container-id-1 div.sk-toggleable {background-color: white;}#sk-container-id-1 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-1 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-1 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-1 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-1 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-1 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-1 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-1 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-1 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-1 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-1 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-1 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-1 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-1 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-1 div.sk-item {position: relative;z-index: 1;}#sk-container-id-1 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-1 div.sk-item::before, #sk-container-id-1 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-1 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-1 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-1 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-1 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-1 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-1 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-1 div.sk-label-container {text-align: center;}#sk-container-id-1 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-1 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-1" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>LinearRegression()</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-1" type="checkbox" checked><label for="sk-estimator-id-1" class="sk-toggleable__label sk-toggleable__label-arrow">LinearRegression</label><div class="sk-toggleable__content"><pre>LinearRegression()</pre></div></div></div></div></div>



# Coefficients results


```python
# Print the intercept and coefficients
print(lr.intercept_)
print(lr.coef_)
```

    4.714126402214131
    [0.05450927 0.10094536 0.00433665]
    

# prediction


```python
y_pred = lr.predict(X_test)
y_pred
```




    array([17.0347724 , 20.40974033, 23.72398873,  9.27278518, 21.68271879,
           12.56940161, 21.08119452,  8.69035045, 17.23701254, 16.66657475,
            8.92396497,  8.4817344 , 18.2075123 ,  8.06750728, 12.64550975,
           14.93162809,  8.12814594, 17.89876565, 11.00880637, 20.47832788,
           20.80631846, 12.59883297, 10.9051829 , 22.38854775,  9.41796094,
            7.92506736, 20.83908497, 13.81520938, 10.77080925,  7.92682509,
           15.95947357, 10.63490851, 20.80292008, 10.43434164, 21.5784752 ,
           21.18364487, 12.12821771, 22.80953262, 12.60992766,  6.46441252])




```python
y_test
```




    95     16.9
    15     22.4
    30     21.4
    158     7.3
    128    24.7
    115    12.6
    69     22.3
    170     8.4
    174    16.5
    45     16.1
    66     11.0
    182     8.7
    165    16.9
    78      5.3
    186    10.3
    177    16.7
    56      5.5
    152    16.6
    82     11.3
    68     18.9
    124    19.7
    16     12.5
    148    10.9
    93     22.2
    65     11.3
    60      8.1
    84     21.7
    67     13.4
    125    10.6
    132     5.7
    9      15.6
    18     11.3
    55     23.7
    75      8.7
    150    16.1
    104    20.7
    135    11.6
    137    20.8
    164    11.9
    76      6.9
    Name: Sales, dtype: float64



# compare actual output vs predicted


```python
plt.figure(figsize=(7, 5))
plt.scatter(y_test, y_pred)
plt.plot([y_test.min(), y_test.max()],
         [y_test.min(), y_test.max()],
         linestyle='--')

plt.xlabel("Actual Sales")
plt.ylabel("Predicted Sales")
plt.title("Actual vs Predicted Sales - Linear Regression")
plt.show()

```

    The history saving thread hit an unexpected error (OperationalError('attempt to write a readonly database')).History will not be written to the database.
    


    
![png](output_35_1.png)
    



```python
plt.figure(figsize=(10, 4))
plt.plot(y_test.values, label='Actual')
plt.plot(y_pred, label='Predicted')
plt.legend()
plt.title("Actual vs Predicted Sales")
plt.show()

```


    
![png](output_36_0.png)
    



```python
residuals = y_test - y_pred

plt.figure(figsize=(7, 5))
plt.scatter(y_pred, residuals)
plt.axhline(0, linestyle='--')

plt.xlabel("Predicted Sales")
plt.ylabel("Residuals")
plt.title("Residual Plot")
plt.show()

```


    
![png](output_37_0.png)
    


# evaluate the mode


```python
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
```


```python
print("Linear Regression R2:", r2_score(y_test, y_pred))
print("Linear Regression MAE:", mean_absolute_error(y_test, y_pred))
print("Linear Regression MSE:", mean_squared_error(y_test, y_pred))

```

    Linear Regression R2: 0.9059011844150826
    Linear Regression MAE: 1.2748262109549338
    Linear Regression MSE: 2.907756910271091
    


```python
import matplotlib.pyplot as plt
plt.scatter(y_test,y_pred)
plt.xlabel('Y Test')
plt.ylabel('Predicted Y')
```




    Text(0, 0.5, 'Predicted Y')




    
![png](output_41_1.png)
    


# using regularization to get best score (ridge & lasso)


```python
from sklearn.linear_model import Ridge , Lasso
```


```python
lasso = Lasso(alpha=0.01)
lasso.fit(X_train, y_train)

y_pred_lasso = lasso.predict(X_test)
print("Lasso R2:", r2_score(y_test, y_pred_lasso))

```

    Lasso R2: 0.9058967115743171
    


```python
ridge = Ridge(alpha=1.0)
ridge.fit(X_train, y_train)

y_pred_ridge = ridge.predict(X_test)
print("Ridge R2:", r2_score(y_test, y_pred_ridge))

```

    Ridge R2: 0.9058999159458063
    

#  Coefficients compare 


```python
coef_df = pd.DataFrame({
    'Linear': lr.coef_,
    'Ridge': ridge.coef_,
    'Lasso': lasso.coef_
}, index=X.columns)

coef_df.plot(kind='bar', title='Feature Importance Comparison')
plt.show()
```


    
![png](output_47_0.png)
    


# Hyperparameter Tuning ( choose best Alpha) & balance bias and variance 




```python
from sklearn.model_selection import GridSearchCV
```


```python
param_grid_ridge = {'alpha': [0.01, 0.1, 1, 10, 100]}

grid_ridge = GridSearchCV(
    Ridge(),
    param_grid_ridge,
    cv=5,
    scoring='r2'
)

grid_ridge.fit(X_train, y_train)

print("Best Ridge Alpha:", grid_ridge.best_params_)

```

    Best Ridge Alpha: {'alpha': 100}
    

**BEST VALUE FOR ALPHA IN RIDGE IS 100 **

# USE GRIDSEARCHCV FOR FIND BEST VALUE FOR ALPHA IN LASSO & RIDGE


```python
param_grid_lasso = {'alpha': [0.001, 0.01, 0.1, 1]}

grid_lasso = GridSearchCV(
    Lasso(max_iter=5000),
    param_grid_lasso,
    cv=5,
    scoring='r2'
)

grid_lasso.fit(X_train, y_train)

print("Best Lasso Alpha:", grid_lasso.best_params_)

```

    Best Lasso Alpha: {'alpha': 0.1}
    


```python
plt.figure(figsize=(10, 4))
plt.plot(y_test.values, label='Actual')
plt.plot(y_pred_lasso, label='Predicted')
plt.legend()
plt.title("Actual vs Predicted Sales")
plt.show()
```


    
![png](output_55_0.png)
    



```python
plt.figure(figsize=(10, 4))
plt.plot(y_test.values, label='Actual')
plt.plot(y_pred_ridge, label='Predicted')
plt.legend()
plt.title("Actual vs Predicted Sales")
plt.show()
```


    
![png](output_56_0.png)
    


**BEST VALUE FOR ALPHA IN LASSO IS 0.1**


```python
from sklearn.preprocessing import PolynomialFeatures
```


```python
from sklearn.pipeline import Pipeline
```

# use PolynomialFeatures


```python
poly_model = Pipeline([
    ('poly', PolynomialFeatures(degree=2, include_bias=False)),
    ('lr', LinearRegression())
])

poly_model.fit(X_train, y_train)

y_pred_poly = poly_model.predict(X_test)

print("Polynomial Regression R2:", r2_score(y_test, y_pred_poly))

```

    Polynomial Regression R2: 0.9533174341074847
    


```python
plt.figure(figsize=(10, 4))
plt.plot(y_test.values, label='Actual')
plt.plot(y_pred_poly, label='Predicted')
plt.legend()
plt.title("Actual vs Predicted Sales")
plt.show()
```


    
![png](output_62_0.png)
    



```python
plt.figure(figsize=(7, 5))
plt.scatter(y_test, y_pred_poly)
plt.plot([y_test.min(), y_test.max()],
         [y_test.min(), y_test.max()],
         linestyle='--')

plt.xlabel("Actual Sales")
plt.ylabel("Predicted Sales")
plt.title("Actual vs Predicted Sales - Linear Regression")
plt.show()

```


    
![png](output_63_0.png)
    



```python

```

# final insights 


```python
print("""
Final Insights:
- TV advertising has the strongest impact on Sales
- Ridge improves model stability
- Lasso highlights unimportant features
- Polynomial Regression slightly improves performance but reduces interpretability
""")

```

    
    Final Insights:
    - TV advertising has the strongest impact on Sales
    - Ridge improves model stability
    - Lasso highlights unimportant features
    - Polynomial Regression slightly improves performance but reduces interpretability
    
    
